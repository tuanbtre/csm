<?php
return [
   'home' => 'home',
   'swaphome'=>'trangchu',
   'aboutus' =>'aboutus',
   'news' =>'news',
   'newsdetail' =>'newsdetail',
   'search' => 'search',
   'contact' => 'contact',
   'contactmail' => 'contactmail',
];