<?php
return [
   'home' => 'Home page',
   'aboutus'=>'About us',
   'news'=>'News',
   'contact' => 'Contact',
   'search' => 'Search',
   'errorlink' => 'Url does not exist',
   'fullname' => 'Full name(*)',
   'email' => 'E-mail(*)',
   'phone' => 'Phone(*)',
   'address' => 'Address(*)',
   'object' => 'Subject',
   'content' => 'Content',
   'locale' => 'en_US', //ko đc dịch dòng này   
   'language' => 'en', //ko đc dịch dòng này   
   'swapflag' => 'vn.png', //ko đc dịch dòng này   
];