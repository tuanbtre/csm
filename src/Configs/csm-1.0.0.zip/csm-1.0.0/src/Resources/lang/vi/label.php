<?php
return [
   'home' => 'Trang chủ',
   'aboutus'=>'Giới thiệu',
   'news'=>'Tin tức',
   'contact' => 'Liên hệ',
   'search' => 'Tìm kiếm',
   'errorlink' => 'Liên kết không tồn tại',
   'fullname' => 'Họ và tên(*)',
   'email' => 'E-mail(*)',
   'phone' => 'Điện thoại(*)',
   'address' => 'Địa chỉ(*)',
   'object' => 'Chủ đề',
   'content' => 'Nội dung',
   'locale' => 'vi_VN', //ko đc dịch dòng này   
   'language' => 'vi', //ko đc dịch dòng này   
   'swapflag' => 'en.png', //ko đc dịch dòng này   
];