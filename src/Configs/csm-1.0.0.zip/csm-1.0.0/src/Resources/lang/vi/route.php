<?php
return [
   'home' => 'trangchu',
   'swaphome'=>'home',
   'aboutus' =>'gioithieu',
   'news' =>'tintuc',
   'newsdetail' =>'tinct',
   'search' => 'timkiem',
   'contact' => 'lien-he',
   'contactmail' => 'maillienhe',
   'adminservice' => '{1} servicedetail|{2} dichvuct',
   'adminnews' => '{1} newsdetail|{2} tinct',
   'adminsoftware' => '{1} softwaredetail|{2} phanmemct',
   'adminevent' => '{1} promotionevent|{2} sukienkm',
];